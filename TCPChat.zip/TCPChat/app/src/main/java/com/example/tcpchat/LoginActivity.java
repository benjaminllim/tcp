package com.example.tcpchat;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.PrintStream;


public class LoginActivity extends AppCompatActivity {

    public BufferedReader br;
    public PrintStream bw;

    private EditText usernameeditText;
    private EditText passwordeditText;
    private TextView logintextView;
    private TextView usernameview;
    private TextView passwordview;
    private Button loginbutton;
    private int count;
    private TextView attempttextview;
    private CheckBox checkbox;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        logintextView = (TextView)findViewById(R.id.textView1);
        logintextView.setMovementMethod(new ScrollingMovementMethod());
        attempttextview = (TextView)findViewById(R.id.attempttextView);
        attempttextview.setText("");
        usernameeditText = (EditText) findViewById(R.id.sendmessage);
        passwordeditText = (EditText) findViewById(R.id.passwordeditText);
        //passwordeditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        //passwordeditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
        loginbutton = (Button)findViewById(R.id.button5);
        checkbox = (CheckBox)findViewById(R.id.checkbox);

        count = 5;
        loginbutton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

                if(usernameeditText.getText().toString().equals("admin")
                        && passwordeditText.getText().toString().equals("admin")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);

                    //builder.setIcon(R.drawable.ic_check);
                    builder.setTitle("Login is successful");
                    builder.setMessage("Login works");

                    builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();

                } else {
                    count--;
                    Toast.makeText(getApplicationContext(), "Invalid username and password", Toast.LENGTH_SHORT).show();
                    attempttextview.setTextColor(Color.RED);
                    attempttextview.setText("You have " + count + " attempts left");

                    if (count == 0) {
                        loginbutton.setEnabled(false);
                    }
                }


            }
        });
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (!isChecked) {
                    // show password
                    passwordeditText.setTransformationMethod(PasswordTransformationMethod.getInstance());

                } else {
                    // hide password
                    passwordeditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });



    }




    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu (menu);
        MenuItem item1 = menu.add(0, 0, Menu.NONE, "TCP Chat");
        MenuItem item2 = menu.add(0, 1, Menu.NONE, "SQL");
        MenuItem item3 = menu.add(0, 2, Menu.NONE, "Login");

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case 0:
                Intent i1 = new Intent(this, MainActivity.class);
                startActivity (i1);
                return true;
            case 1:
                Intent i2 = new Intent(this, SQLActivity.class);
                startActivity (i2);
                return true;
            case 2:
                Intent i3 = new Intent(this, LoginActivity.class);
                startActivity (i3);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

