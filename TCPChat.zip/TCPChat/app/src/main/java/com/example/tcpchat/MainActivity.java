package com.example.tcpchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    public Socket sender;
    public BufferedReader br;
    public PrintStream bw;

    EditText e, e2, ip, port;
    Button b, b2, connect;
    TextView t, t2, t3;

    int portNumber;
    String ipAddress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t = (TextView) findViewById(R.id.textView);
        t.setMovementMethod(new ScrollingMovementMethod());
        t2 = (TextView) findViewById(R.id.textView2);
        t3 = (TextView) findViewById(R.id.textView3);

        e = (EditText) findViewById(R.id.editText);
        ip = (EditText) findViewById(R.id.ipeditText);
        port = (EditText) findViewById(R.id.porteditText);

//        portNumber = 4455;

//        ipAddress = "10.0.2.2"; // Change this to the IP address of your computer OR “10.0.2.2”(Gateway to 127.0.0.1 of host)

        t2.setVisibility(View.INVISIBLE);
        t3.setVisibility(View.INVISIBLE);

        b = (Button) findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        String s = e.getText().toString();
                        bw.println(s);
                    }
                }.start();
                String s = "Sent " + getTime() + ": " + e.getText().toString();
                String outputtext = t.getText().toString();
                FileOutputStream fos;

                try {
                    fos = openFileOutput("data.txt", Context.MODE_PRIVATE);
                    System.out.println(s);
                    fos.write(s.getBytes(), 0, s.length());
                    fos.close();


                    System.out.println(outputtext);

                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        });

//        Thread t = new Thread(new SocketListener(portNumber, ipAddress));
//        t.start();

        b2 = (Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                byte[] buffer = new byte[1024];
                String s = "";
                String s2 = "";
                int n;
                int n2;

                FileInputStream fin;
                FileInputStream fin2;
                try {
                    fin = openFileInput("data.txt");
                    do {
                        n = fin.read(buffer, 0, 1024);

                        if (n != -1) {
                            s = s + new String(buffer, 0, n);
                        }

                    }
                    while ((n != -1) /*& (n2 != -1)*/);

                    fin.close();

                    fin2 = openFileInput("data2.txt");
                    do {
                        n2 = fin2.read(buffer, 0, 1024);

                        if (n2 != -1) {
                            s2 = s2 + new String(buffer, 0, n2);
                        }

                    }
                    while ((n2 != -1));

                    fin2.close();
                    t2.setVisibility(View.VISIBLE);
                    t3.setVisibility(View.VISIBLE);
                    t2.setText(s);
                    t3.setText(s2);
                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        });

        connect = (Button)findViewById(R.id.connectbutton);
        connect.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                ipAddress = ip.getText().toString();
                try {
                    portNumber = Integer.parseInt(port.getText().toString());
                } catch (NumberFormatException e) {
                    port.setTextColor(Color.RED);
                    port.setText("Invalid port number, please try again");
                }

                Thread t = new Thread (new SocketListener (portNumber, ipAddress));
                t.start();

            }
        });


    }

    class SocketListener implements Runnable {
        String str;
        int portNumber;
        String ipAddress;
        SocketListener() {
            this.portNumber = portNumber;
            this.ipAddress = ipAddress;

        }

        SocketListener(int portNumber, String ipAddress) {
           this.portNumber = portNumber;
           this.ipAddress = ipAddress;

        }
        public void run() {
            try {
                sender = new Socket(this.ipAddress, this.portNumber);
                br = new BufferedReader(new InputStreamReader(sender.getInputStream()));
                bw = new PrintStream(sender.getOutputStream());
                bw.println("Connected");

                while (true) {
                    String s = br.readLine();
                    CharSequence cs = t.getText();
                    str = cs + "\r\n" + s;

                    t.post(new Runnable() {
                               public void run() {
                                   t.setText(str + " : " + getTime());
                               }
                           }
                    );
                }

            } catch (IOException e) {
                Log.e(getClass().getName(), e.getMessage());
            }
        }
    }

    String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuItem item1 = menu.add(0, 0, Menu.NONE, "TCP Chat");
        MenuItem item2 = menu.add(0, 1, Menu.NONE, "SQL");
        MenuItem item3 = menu.add(0, 2, Menu.NONE, "Login");

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                Intent i1 = new Intent(this, MainActivity.class);
                startActivity(i1);
                return true;
            case 1:
                Intent i2 = new Intent(this, SQLActivity.class);
                startActivity(i2);
                return true;
            case 2:
                Intent i3 = new Intent(this, LoginActivity.class);
                startActivity(i3);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

