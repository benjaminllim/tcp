package com.example.tcpchat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SQLActivity extends AppCompatActivity {

    EditText e1;
    Button b1, b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sql);

        e1 = (EditText)findViewById(R.id.editText);

        b1 = (Button)findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener()
                              {
                                  public void onClick (View view)
                                  {
                                      String n = e1.getText().toString();

                                      FileOutputStream fos;
                                      try
                                      {
                                          fos = openFileOutput ("data.txt", Context.MODE_PRIVATE);
                                          fos.write (n.getBytes(), 0, n.length());
                                          fos.close();
                                      }
                                      catch (FileNotFoundException e)
                                      {
                                          // TODO Auto-generated catch block
                                          e.printStackTrace();
                                      }
                                      catch (IOException e)
                                      {
                                          // TODO Auto-generated catch block
                                          e.printStackTrace();
                                      }

                                  }
                              }
        );

        b2 = (Button)findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener()
                              {
                                  public void onClick (View view)
                                  {
                                      byte[] buffer = new byte[1024];
                                      String s = "";
                                      int n;

                                      FileInputStream fin;
                                      try
                                      {
                                          fin = openFileInput ("data.txt");
                                          do
                                          {
                                              n = fin.read (buffer, 0, 1024);

                                              if ( n != -1)
                                              {
                                                  s = s + new String (buffer, 0, n);
                                              }

                                          }
                                          while ((n != -1));
                                          fin.close();

                                          e1.setText(s);
                                      }
                                      catch (FileNotFoundException e)
                                      {
                                          // TODO Auto-generated catch block
                                          e.printStackTrace();
                                      }
                                      catch (IOException e)
                                      {
                                          // TODO Auto-generated catch block
                                          e.printStackTrace();
                                      }

                                  }
                              }
        );
    }
}